﻿using System;
using System.Web;

namespace UIControlsPrototype
{
	public class Global : HttpApplication
	{
		#region Protecteds
		protected void Application_Start(object sender, EventArgs e)
		{
		}
		#endregion
	}
}