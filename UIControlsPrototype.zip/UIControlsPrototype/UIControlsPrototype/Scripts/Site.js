﻿
function SetGridHeight(e)
{
    var grid = document.getElementById(e.model.clientId);
    var nWindowHeight = document.documentElement.clientHeight;
    var nHeight = nWindowHeight - (ADCOM_GetOffsetFromRoot(grid, "top") + 70);

    e.model.scrollSettings.height = nHeight;

    var nWidth = document.documentElement.clientWidth - $(grid).offset().left - 20;
    e.model.scrollSettings.width = nWidth;
}

function ADCOM_GetOffsetFromRoot(element, offset)
{
    var nOffsetTop = 0;
    while(element)
    {
        nOffsetTop += $(element).offset()[offset];
        element = element.offsetParent;
    }

    return nOffsetTop;
}
function Complete(args)
{
    if(args.requestType == "grouping")
    {
        this.option({ toolbarSettings: { showToolbar: true } }); // Show toolbar using setmodel 
    }
    if(args.requestType == "ungrouping" && !this.model.groupSettings.groupedColumns.length)
    { // get the grouped columns from groupSettings. 
        this.option({ toolbarSettings: { showToolbar: false } }); // hide toolbar using setmodel when there is no grouping. 
    }
}

function onToolBarClick(sender)
{
    if(sender.itemName == "Expand") this.expandAll();
    else if(sender.itemName == "Collapse") this.collapseAll();
    else this.refreshContent();
}
function load(args)
{
    this.element.mousedown(function(e)
    {
        if(e.metaKey)
        {
            var grid = $("#MainContent_TripGridAll").data('ejGrid');
            grid.multiSortRequest = true;
        }
    });
}