﻿using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;

namespace UIControlsPrototype
{
    internal class MenuStructure
    {
        public static List<Menu> GetMenuStructures(string strPath)
        {
            return JsonConvert.DeserializeObject<List<Menu>>(File.ReadAllText(strPath));
        }
    }
    public class Menu
    {
        public string Id { get; set; }
        public string ParentId { get; set; }
        public string SeqNr { get; set; }
        public string TechName { get; set; }
        public string SectionCd { get; set; }
        public string Caption { get; set; }
        public string DocumentName { get; set; }
        public string Security { get; set; }
        public string SecurityInherited { get; set; }
        public string Path { get; set; }
        public string PackageId { get; set; }

        public string Guid { get; set; }
        public string RowState { get; set; }
        
    }
}