﻿using System;
using System.Web.UI;

namespace UIControlsPrototype
{
	public partial class Site : MasterPage
	{
		#region Protecteds
		protected void Page_Load(object sender, EventArgs e)
		{
		}
		#endregion
	}
}