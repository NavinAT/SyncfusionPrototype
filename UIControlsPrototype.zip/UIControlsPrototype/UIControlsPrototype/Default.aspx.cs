﻿using System;
using System.Web.UI;

namespace UIControlsPrototype
{
	public partial class Default : Page
	{
		#region Protecteds
		protected void Page_Load(object sender, EventArgs e)
		{
			this.Response.Redirect("/DataGrid/GridView_50_All.aspx");
		}
		#endregion
	}
}