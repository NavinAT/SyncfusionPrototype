﻿using System;
using System.IO;
using System.Web.UI;
using Syncfusion.JavaScript;
using Syncfusion.JavaScript.Web;

namespace UIControlsPrototype.DataGrid
{
    public partial class ucGridAllFeatures : UserControl
    {
        #region Properties
        public string DataPath { get; set; }
        #endregion

        #region Protecteds
        protected void Page_Load(object sender, EventArgs e)
        {
            BindDataSource();
        }

        protected void onShowHideGroupDropArea(object sender, ToggleButtonEventArgs e)
        {
            TripGridAll.GroupSettings.ShowDropArea = !TripGridAll.GroupSettings.ShowDropArea;
        }

        protected void OnItemSelect(object sender, GroupButtonEventArgs e)
        {
            switch(FilterSettings.Items[(int) e.Arguments["index"]].Text)
            {
                case "Menu Filter":
                    TripGridAll.FilterSettings.FilterType = FilterType.Menu;
                    break;
                case "Column Filter":
                    TripGridAll.FilterSettings.FilterType = FilterType.FilterBar;
                    break;
                default:
                    TripGridAll.FilterSettings.FilterType = FilterType.Excel;
                    break;
            }
        }
        #endregion

        #region Privates
        private void BindDataSource()
        {
            TripGridAll.DataSource = MenuStructure.GetMenuStructures(Path.Combine(this.Request.MapPath("~"), this.DataPath));
            TripGridAll.DataBind();
        }
        #endregion
    }
}