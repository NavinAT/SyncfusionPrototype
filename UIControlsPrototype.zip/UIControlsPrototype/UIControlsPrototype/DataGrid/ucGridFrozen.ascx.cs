﻿using System;
using System.Web.UI;
using System.IO;
using Syncfusion.JavaScript;
using Syncfusion.JavaScript.Web;

namespace UIControlsPrototype.DataGrid
{
    public partial class ucGridFrozen : UserControl
    {
        #region Properties
        public string DataPath { get; set; }
        #endregion

        #region Protecteds
        protected void Page_Load(object sender, EventArgs e)
        {
            BindDataSource();
        }

        protected void OnItemSelect(object sender, GroupButtonEventArgs e)
        {
            switch(FilterSettings.Items[(int) e.Arguments["index"]].Text)
            {
                case "Menu Filter":
                    TripGridFrozon.FilterSettings.FilterType = FilterType.Menu;
                    break;
                case "Column Filter":
                    TripGridFrozon.FilterSettings.FilterType = FilterType.FilterBar;
                    break;
                default:
                    TripGridFrozon.FilterSettings.FilterType = FilterType.Excel;
                    break;
            }
        }
        #endregion

        #region Privates
        private void BindDataSource()
        {
            TripGridFrozon.DataSource = MenuStructure.GetMenuStructures(Path.Combine(this.Request.MapPath("~"), this.DataPath));
            TripGridFrozon.DataBind();
        }
        #endregion
    }
}