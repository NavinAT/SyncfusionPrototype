﻿using System;
using System.Web.UI;

namespace UIControlsPrototype.DataGrid
{
    public partial class GridView_1000_Frozen : Page
    {
        #region Protecteds
        protected void Page_Load(object sender, EventArgs e)
        {
        }
        #endregion
    }
}