﻿using System;
using System.IO;
using System.Web.UI;
using Syncfusion.JavaScript;
using Syncfusion.JavaScript.Web;

namespace UIControlsPrototype.DataGrid
{
	public partial class GridView_1000_All : Page
	{
        #region Constants
        //private const string MENU_JSON_PATH = "Json/Menustructure1800.json";
        #endregion

        #region Protecteds
        protected void Page_Load(object sender, EventArgs e)
        {
            //BindDataSource();
        }
        #endregion

        #region Privates
        private void BindDataSource()
        {
            
            //TripGridAll.DataSource = MenuStructure.GetMenuStructures(Path.Combine(this.Request.MapPath("~"), MENU_JSON_PATH));
            //TripGridAll.DataBind();
        }
        #endregion
    }
}